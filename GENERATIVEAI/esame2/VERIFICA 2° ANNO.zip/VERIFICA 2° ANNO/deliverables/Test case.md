# Test case del sistema di rimborsi

## T01 — Approvazione automatica di CLM001

**Input iniziale**

> Sono il dipendente E001. Vorrei sapere se la spesa CLM001 per il treno da 110 EUR del 2026-10-08 può essere rimborsata.

**Esito atteso e motivazione.** `APPROVABILE`, senza pausa per approvazione umana. Il claim appartiene a E001, la categoria `travel_train` è consentita per il suo ruolo, la ricevuta R001 è presente e 110 EUR non supera né il limite di 250 EUR né la soglia di approvazione di 150 EUR. Il Reviewer deve confermare la coerenza dell'esito.

**Interazioni successive.** Nessuna.

**Output osservato.** Regole: `APPROVABILE`; Reviewer coerente: `True`. Risposta finale:

> Richiesta CLM001: APPROVABILE. Dipendente, categoria, ricevuta e importo rispettano la policy. Approvazione automatica secondo la policy.

**Risultato del test:** conforme all'atteso.

## T02 — Rifiuto di CLM003 per ricevuta mancante

**Input iniziale**

> Sono il dipendente E001. Vorrei sapere se la spesa CLM003 per la cena da 48 EUR del 2026-10-08 può essere rimborsata.

**Esito atteso e motivazione.** `NON_APPROVABILE`. La policy della categoria `meal` richiede una ricevuta, ma nel claim `receipt_id` è assente. Questa regola determina il rifiuto anche se l'importo è inferiore al limite di 60 EUR. Non serve una decisione umana.

**Interazioni successive.** Nessuna.

**Output osservato.** Regole: `NON_APPROVABILE`; Reviewer coerente: `True`. Risposta finale:

> Richiesta CLM003: NON_APPROVABILE. Manca la ricevuta obbligatoria.

**Risultato del test:** conforme all'atteso.

## T03 — CLM002 sopra la soglia e rifiuto umano

**Input iniziale**

> Sono il dipendente E002. Vorrei sapere se la spesa CLM002 per l'hotel da 240 EUR del 2026-10-08 può essere rimborsata.

**Esito atteso e motivazione.** Le regole devono restituire `NECESSARIA_APPROVAZIONE`: 240 EUR supera la soglia di approvazione di 180 EUR per `hotel`, ma resta entro il limite massimo di 300 EUR. Se il Reviewer ritiene coerente l'esito, il workflow deve sospendersi e chiedere la decisione del responsabile. Un rifiuto umano deve produrre l'esito finale `NON_APPROVABILE`.

**Output osservato prima dell'intervento umano.** Regole: `NECESSARIA_APPROVAZIONE`; motivazione: `L'importo di 240 EUR supera la soglia di 180 EUR.`; Reviewer coerente: `True`. Il workflow si è fermato con la domanda:

> Approvi questa richiesta di rimborso?

**Interazione successiva.** Ripresa con `Command(resume={"approvato": False, "nota": "Spesa non autorizzata dal responsabile."})`.

**Output osservato dopo l'intervento umano.** Decisione: `RIFIUTATO`; esito finale: `NON_APPROVABILE`. Risposta finale:

> Richiesta CLM002: NON_APPROVABILE. L'importo di 240 EUR supera la soglia di 180 EUR. Il responsabile ha rifiutato la richiesta. Nota del responsabile: Spesa non autorizzata dal responsabile.

**Risultato del test:** conforme all'atteso.

## T04 — Chiarimento della data mancante per CLM001

**Input iniziale**

> Sono il dipendente E001. La spesa CLM001 è per un treno da 110 EUR. Posso ottenere il rimborso?

**Esito atteso e motivazione.** La data della spesa manca dalla richiesta iniziale. Il Request Agent deve registrare `expense_date` tra le informazioni mancanti; il workflow deve fermarsi per chiedere la data. Dopo il chiarimento, il testo aggiornato deve tornare al Request Agent e la pratica deve essere valutata di nuovo.

**Output osservato prima del chiarimento.** Campo mancante: `expense_date`. Domanda mostrata all'utente:

> Per valutare il rimborso, indica: la data della spesa.

**Interazione successiva.** Ripresa con `Command(resume="La spesa è del 2026-10-08.")`.

**Output osservato dopo il chiarimento.** Data interpretata: `2026-10-08`; regole: `APPROVABILE`. Risposta finale:

> Richiesta CLM001: APPROVABILE. Dipendente, categoria, ricevuta e importo rispettano la policy. Approvazione automatica secondo la policy.

**Risultato del test:** conforme all'atteso.
